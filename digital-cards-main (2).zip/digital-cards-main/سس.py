#!/usr/bin/env python
# coding: utf-8

# In[3]:


from IPython.display import HTML

html_code = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>بطاقات رقمية | Digital Cards</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0a1628; color: #ffffff; direction: rtl; }
    header { background: linear-gradient(135deg, #0d1f3c, #1a3a6e); padding: 18px 40px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 15px rgba(0,0,0,0.4); position: sticky; top: 0; z-index: 100; }
    header .logo { font-size: 1.6rem; font-weight: 700; color: #ffffff; letter-spacing: 1px; }
    header .logo span { color: #4a9eff; }
    nav a { color: #cce0ff; text-decoration: none; margin-left: 25px; font-size: 0.95rem; transition: color 0.3s; }
    nav a:hover { color: #4a9eff; }
    .hero { background: linear-gradient(160deg, #0d1f3c 0%, #1a3a6e 60%, #0a2850 100%); text-align: center; padding: 80px 20px 60px; position: relative; overflow: hidden; }
    .hero h1 { font-size: 2.8rem; margin-bottom: 15px; color: #ffffff; }
    .hero h1 span { color: #4a9eff; }
    .hero p { font-size: 1.1rem; color: #a8c4e8; max-width: 600px; margin: 0 auto 30px; line-height: 1.8; }
    .hero-btn { background: linear-gradient(135deg, #1e5bbf, #4a9eff); color: white; padding: 14px 40px; border: none; border-radius: 30px; font-size: 1.1rem; cursor: pointer; text-decoration: none; display: inline-block; transition: transform 0.2s, box-shadow 0.2s; box-shadow: 0 4px 20px rgba(74,158,255,0.4); }
    .hero-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 25px rgba(74,158,255,0.6); }
    .card-logos { display: flex; justify-content: center; align-items: center; gap: 20px; margin-top: 35px; flex-wrap: wrap; }
    .card-logo-badge { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); border-radius: 12px; padding: 10px 22px; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; color: #cce0ff; }
    .visa-logo { font-weight: 900; font-size: 1.3rem; font-style: italic; letter-spacing: -1px; color: #1a73e8; background: white; padding: 2px 8px; border-radius: 4px; }
    .mc-logo { display: flex; align-items: center; }
    .mc-circle { width: 22px; height: 22px; border-radius: 50%; }
    .mc-red { background: #eb001b; }
    .mc-orange { background: #f79e1b; margin-right: -8px; opacity: 0.9; }
    .section-title { text-align: center; font-size: 2rem; margin: 60px 0 10px; color: #ffffff; }
    .section-title span { color: #4a9eff; }
    .section-sub { text-align: center; color: #7a9bbf; margin-bottom: 45px; font-size: 1rem; }
    .products { display: flex; justify-content: center; flex-wrap: wrap; gap: 30px; padding: 0 30px 60px; max-width: 1100px; margin: 0 auto; }
    .product-card { background: linear-gradient(145deg, #112244, #1a3a6e); border: 1px solid rgba(74,158,255,0.2); border-radius: 20px; padding: 35px 30px; width: 300px; text-align: center; transition: transform 0.3s, box-shadow 0.3s, border-color 0.3s; position: relative; overflow: hidden; }
    .product-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #1e5bbf, #4a9eff, #1e5bbf); }
    .product-card:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(74,158,255,0.25); border-color: rgba(74,158,255,0.5); }
    .product-card.popular { border-color: #4a9eff; box-shadow: 0 5px 25px rgba(74,158,255,0.2); }
    .badge-popular { position: absolute; top: 18px; left: 18px; background: linear-gradient(135deg, #1e5bbf, #4a9eff); color: white; font-size: 0.75rem; padding: 4px 12px; border-radius: 20px; font-weight: 600; }
    .product-icon { font-size: 3rem; margin-bottom: 15px; }
    .product-title { font-size: 1.3rem; font-weight: 700; margin-bottom: 10px; color: #ffffff; }
    .product-desc { color: #7a9bbf; font-size: 0.9rem; line-height: 1.7; margin-bottom: 20px; }
    .product-price { font-size: 2.2rem; font-weight: 800; color: #4a9eff; margin-bottom: 5px; }
    .product-price span { font-size: 1rem; color: #7a9bbf; }
    .product-features { list-style: none; margin: 15px 0 25px; text-align: right; }
    .product-features li { color: #a8c4e8; font-size: 0.88rem; padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
    .product-features li::before { content: 'checkmark '; color: #4a9eff; font-weight: bold; }
    .buy-btn { width: 100%; padding: 13px; background: linear-gradient(135deg, #1e5bbf, #4a9eff); color: white; border: none; border-radius: 12px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: opacity 0.2s, transform 0.2s; box-shadow: 0 4px 15px rgba(74,158,255,0.3); }
    .buy-btn:hover { opacity: 0.9; transform: scale(1.02); }
    .buy-btn.outline { background: transparent; border: 2px solid #4a9eff; color: #4a9eff; }
    .buy-btn.outline:hover { background: rgba(74,158,255,0.1); }

    /* ===== LOUNGE SECTION ===== */
    .lounge-section { background: linear-gradient(135deg, #071828, #0d2a4a); padding: 70px 30px; }
    .lounge-header { text-align: center; margin-bottom: 50px; }
    .lounge-header h2 { font-size: 2rem; color: #ffffff; margin-bottom: 10px; }
    .lounge-header h2 span { color: #4a9eff; }
    .lounge-header p { color: #7a9bbf; font-size: 1rem; }
    .lounge-cards { display: flex; justify-content: center; flex-wrap: wrap; gap: 25px; max-width: 1100px; margin: 0 auto 50px; }
    .lounge-card { background: linear-gradient(145deg, #0d1f3c, #1a3a6e); border: 1px solid rgba(74,158,255,0.25); border-radius: 18px; padding: 30px 25px; width: 280px; text-align: center; transition: transform 0.3s, box-shadow 0.3s; position: relative; overflow: hidden; }
    .lounge-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #gold, #4a9eff); }
    .lounge-card:hover { transform: translateY(-6px); box-shadow: 0 12px 35px rgba(74,158,255,0.2); }
    .lounge-card .card-type { font-size: 0.8rem; color: #4a9eff; font-weight: 600; letter-spacing: 1px; margin-bottom: 8px; text-transform: uppercase; }
    .lounge-card .card-name { font-size: 1.2rem; font-weight: 700; color: #ffffff; margin-bottom: 12px; }
    .lounge-card .card-network { display: flex; justify-content: center; margin-bottom: 15px; }
    .lounge-card ul { list-style: none; text-align: right; margin-bottom: 20px; }
    .lounge-card ul li { color: #a8c4e8; font-size: 0.85rem; padding: 4px 0; border-bottom: 1px solid rgba(255,255,255,0.04); }
    .lounge-card ul li::before { content: 'star '; color: #f0c040; }
    .lounge-badge { display: inline-block; background: rgba(74,158,255,0.15); border: 1px solid rgba(74,158,255,0.3); color: #4a9eff; font-size: 0.8rem; padding: 5px 14px; border-radius: 20px; margin-bottom: 15px; }

    /* شروط الصالات */
    .lounge-terms { background: rgba(255,255,255,0.03); border: 1px solid rgba(74,158,255,0.15); border-radius: 18px; padding: 35px; max-width: 900px; margin: 0 auto 40px; }
    .lounge-terms h3 { font-size: 1.3rem; color: #4a9eff; margin-bottom: 25px; text-align: center; }
    .terms-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .term-item { background: rgba(255,255,255,0.03); border-radius: 12px; padding: 20px; border-right: 3px solid #4a9eff; }
    .term-item h4 { color: #ffffff; font-size: 0.95rem; margin-bottom: 8px; }
    .term-item p { color: #7a9bbf; font-size: 0.85rem; line-height: 1.6; }

    /* معالم دولية */
    .networks-bar { display: flex; justify-content: center; align-items: center; flex-wrap: wrap; gap: 15px; margin-top: 30px; }
    .network-badge { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 10px 20px; color: #cce0ff; font-size: 0.85rem; display: flex; align-items: center; gap: 8px; }

    .payment-section { background: linear-gradient(135deg, #0d1f3c, #112244); padding: 50px 20px; text-align: center; border-top: 1px solid rgba(74,158,255,0.1); border-bottom: 1px solid rgba(74,158,255,0.1); }
    .payment-section h3 { font-size: 1.3rem; color: #cce0ff; margin-bottom: 25px; }
    .payment-icons { display: flex; justify-content: center; align-items: center; flex-wrap: wrap; gap: 20px; }
    .payment-icon { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 14px 28px; display: flex; align-items: center; gap: 10px; color: #cce0ff; font-size: 0.95rem; font-weight: 500; }
    .features { display: flex; justify-content: center; flex-wrap: wrap; gap: 25px; padding: 60px 30px; max-width: 1000px; margin: 0 auto; }
    .feature-box { background: rgba(255,255,255,0.04); border: 1px solid rgba(74,158,255,0.15); border-radius: 16px; padding: 30px 25px; width: 200px; text-align: center; transition: border-color 0.3s; }
    .feature-box:hover { border-color: rgba(74,158,255,0.4); }
    .feature-icon { font-size: 2.2rem; margin-bottom: 12px; }
    .feature-box h4 { color: #ffffff; font-size: 1rem; margin-bottom: 8px; }
    .feature-box p { color: #7a9bbf; font-size: 0.85rem; line-height: 1.6; }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 999; justify-content: center; align-items: center; backdrop-filter: blur(4px); }
    .modal-overlay.active { display: flex; }
    .modal { background: linear-gradient(145deg, #112244, #1a3a6e); border: 1px solid rgba(74,158,255,0.3); border-radius: 20px; padding: 40px 35px; width: 95%; max-width: 420px; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.5); }
    .modal h3 { font-size: 1.4rem; margin-bottom: 8px; color: #ffffff; }
    .modal p.sub { color: #7a9bbf; font-size: 0.9rem; margin-bottom: 25px; }
    .modal .price-display { background: rgba(74,158,255,0.1); border: 1px solid rgba(74,158,255,0.3); border-radius: 12px; padding: 15px; text-align: center; font-size: 1.8rem; font-weight: 800; color: #4a9eff; margin-bottom: 25px; }
    .modal label { display: block; color: #a8c4e8; font-size: 0.9rem; margin-bottom: 6px; }
    .modal input, .modal select { width: 100%; padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(74,158,255,0.3); background: rgba(255,255,255,0.05); color: white; font-size: 0.95rem; margin-bottom: 15px; outline: none; transition: border-color 0.3s; direction: rtl; }
    .modal input:focus, .modal select:focus { border-color: #4a9eff; }
    .modal select option { background: #1a3a6e; color: white; }
    .modal .btn-confirm { width: 100%; padding: 14px; background: linear-gradient(135deg, #1e5bbf, #4a9eff); color: white; border: none; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; margin-top: 5px; box-shadow: 0 4px 20px rgba(74,158,255,0.35); transition: opacity 0.2s; }
    .modal .btn-confirm:hover { opacity: 0.9; }
    .modal .close-btn { position: absolute; top: 15px; left: 15px; background: none; border: none; color: #7a9bbf; font-size: 1.5rem; cursor: pointer; line-height: 1; }
    .modal .close-btn:hover { color: white; }
    .success-msg { display: none; text-align: center; padding: 20px 0; }
    .success-msg .check { font-size: 4rem; margin-bottom: 15px; }
    .success-msg h3 { color: #4aff8c; font-size: 1.4rem; margin-bottom: 10px; }
    .success-msg p { color: #a8c4e8; font-size: 0.95rem; }
    footer { background: #07111f; text-align: center; padding: 30px 20px; color: #4a6a8a; font-size: 0.85rem; border-top: 1px solid rgba(74,158,255,0.1); }
    .footer-logos { display: flex; justify-content: center; align-items: center; gap: 15px; margin-bottom: 12px; }
    @media (max-width: 600px) {
      .hero h1 { font-size: 1.9rem; }
      .product-card, .lounge-card { width: 100%; max-width: 340px; }
      .feature-box { width: 150px; }
      header { padding: 15px 20px; }
      nav { display: none; }
    }
  </style>
</head>
<body>

<header>
  <div class="logo">Digital<span>Cards</span></div>
  <nav>
    <a href="#">الرئيسية</a>
    <a href="#products">المنتجات</a>
    <a href="#lounge">صالات المطار</a>
    <a href="#features">مميزاتنا</a>
    <a href="#">تواصل معنا</a>
  </nav>
</header>

<section class="hero">
  <h1>بطاقاتك الرقمية <span>بكل سهولة</span></h1>
  <p>احصل على بطاقتك الرقمية أو فعّل فيزا الخاصة بك وادخل صالات المطارات العالمية بأسرع وقت وبأمان تام</p>
  <a href="#products" class="hero-btn">تصفح المنتجات</a>
  <div class="card-logos">
    <div class="card-logo-badge"><span class="visa-logo">VISA</span> بطاقة فيزا</div>
    <div class="card-logo-badge">
      <div class="mc-logo">
        <div class="mc-circle mc-orange"></div>
        <div class="mc-circle mc-red"></div>
      </div>
      ماستر كارد
    </div>
    <div class="card-logo-badge">✈️ Priority Pass</div>
    <div class="card-logo-badge">🔒 دفع آمن 100%</div>
  </div>
</section>

<!-- PRODUCTS -->
<h2 class="section-title" id="products">منتجاتنا <span>المتاحة</span></h2>
<p class="section-sub">اختر المنتج المناسب لك وأتم الطلب في دقيقة واحدة</p>
<div class="products">
  <div class="product-card">
    <div class="product-icon">💳</div>
    <div class="product-title">بطاقة رقمية</div>
    <div class="product-desc">بطاقة رقمية مسبقة الدفع للاستخدام الفوري عبر الإنترنت</div>
    <div class="product-price">$5 <span>USD</span></div>
    <ul class="product-features">
      <li>صالحة للاستخدام الفوري</li>
      <li>تعمل مع جميع المواقع</li>
      <li>تسليم فوري عبر البريد</li>
    </ul>
    <button class="buy-btn outline" onclick="openModal('بطاقة رقمية 5$', '$5.00')">اشتري الآن</button>
  </div>
  <div class="product-card popular">
    <div class="badge-popular">⭐ الأكثر طلباً</div>
    <div class="product-icon">💰</div>
    <div class="product-title">بطاقة رقمية</div>
    <div class="product-desc">بطاقة رقمية مسبقة الدفع بقيمة أعلى للمشتريات الكبيرة</div>
    <div class="product-price">$100 <span>USD</span></div>
    <ul class="product-features">
      <li>صالحة للاستخدام الفوري</li>
      <li>تعمل مع جميع المواقع</li>
      <li>تسليم فوري عبر البريد</li>
      <li>دعم فني مخصص</li>
    </ul>
    <button class="buy-btn" onclick="openModal('بطاقة رقمية 100$', '$100.00')">اشتري الآن</button>
  </div>
  <div class="product-card">
    <div class="product-icon">✅</div>
    <div class="product-title">تفعيل فيزا</div>
    <div class="product-desc">خدمة تفعيل بطاقة الفيزا الخاصة بك بسرعة وأمان كامل</div>
    <div class="product-price" style="font-size:1.3rem;">تواصل للسعر</div>
    <ul class="product-features">
      <li>تفعيل خلال دقائق</li>
      <li>دعم جميع أنواع الفيزا</li>
      <li>ضمان الأمان الكامل</li>
      <li>خدمة عملاء 24/7</li>
    </ul>
    <button class="buy-btn" onclick="openModal('تفعيل فيزا', 'تواصل للسعر')">اطلب الخدمة</button>
  </div>
</div>

<!-- LOUNGE SECTION -->
<section class="lounge-section" id="lounge">
  <div class="lounge-header">
    <h2>✈️ تفعيل البطاقات البنكية <span>لزيارة صالات المطار</span></h2>
    <p>ادخل أكثر من 1,300 صالة مطار حول العالم عبر بطاقتك البنكية</p>
  </div>

  <div class="lounge-cards">
    <div class="lounge-card">
      <div class="card-type">Visa</div>
      <div class="card-name">Visa Infinite</div>
      <div class="card-network"><span class="visa-logo">VISA</span></div>
      <div class="lounge-badge">Priority Pass مفعّل</div>
      <ul>
        <li>دخول مجاني غير محدود</li>
        <li>مرافق مجاني واحد</li>
        <li>+1,300 صالة عالمياً</li>
        <li>خدمة كونسيرج دولية</li>
      </ul>
      <button class="buy-btn" onclick="openModal('تفعيل Visa Infinite للصالات', 'تواصل للسعر')">فعّل الآن</button>
    </div>

    <div class="lounge-card">
      <div class="card-type">Mastercard</div>
      <div class="card-name">World Elite Mastercard</div>
      <div class="card-network">
        <div class="mc-logo">
          <div class="mc-circle mc-orange"></div>
          <div class="mc-circle mc-red"></div>
        </div>
      </div>
      <div class="lounge-badge">LoungeKey مفعّل</div>
      <ul>
        <li>دخول مجاني 8 مرات سنوياً</li>
        <li>تطبيق LoungeKey</li>
        <li>+1,000 صالة عالمياً</li>
        <li>ضيف بسعر مخفض</li>
      </ul>
      <button class="buy-btn" onclick="openModal('تفعيل World Elite للصالات', 'تواصل للسعر')">فعّل الآن</button>
    </div>

    <div class="lounge-card">
      <div class="card-type">Priority Pass</div>
      <div class="card-name">بطاقة مستقلة</div>
      <div class="card-network">✈️</div>
      <div class="lounge-badge">عضوية مستقلة</div>
      <ul>
        <li>مستقلة عن أي بنك</li>
        <li>+1,400 صالة عالمياً</li>
        <li>خطط متعددة</li>
        <li>تطبيق موبايل</li>
      </ul>
      <button class="buy-btn outline" onclick="openModal('عضوية Priority Pass', 'تواصل للسعر')">فعّل الآن</button>
    </div>
  </div>

  <!-- الشروط الدولية -->
  <div class="lounge-terms">
    <h3>📋 الشروط الدولية لدخول الصالات</h3>
    <div class="terms-grid">
      <div class="term-item">
        <h4>🪪 إثبات الهوية</h4>
        <p>يجب تقديم البطاقة البنكية المفعّلة مع جواز السفر عند الدخول للصالة</p>
      </div>
      <div class="term-item">
        <h4>🎫 بطاقة الصعود</h4>
        <p>يُطلب في معظم الصالات تقديم بطاقة الصعود لرحلة في نفس اليوم</p>
      </div>
      <div class="term-item">
        <h4>👥 المرافقون</h4>
        <p>يُسمح بمرافق واحد مجاناً في بعض البطاقات، وباقي المرافقين برسوم تتراوح بين $27-$35</p>
      </div>
      <div class="term-item">
        <h4>🔢 عدد الزيارات</h4>
        <p>تختلف حسب نوع البطاقة: من 4 زيارات سنوياً إلى غير محدودة للبطاقات البلاتينية</p>
      </div>
      <div class="term-item">
        <h4>⏰ مدة الإقامة</h4>
        <p>الحد الأقصى للإقامة في الصالة عادةً 3 ساعات قبل موعد الرحلة</p>
      </div>
      <div class="term-item">
        <h4>🌍 التغطية الجغرافية</h4>
        <p>الصالات متاحة في أكثر من 148 دولة وأكثر من 600 مطار حول العالم</p>
      </div>
    </div>
  </div>

  <!-- شبكات الصالات -->
  <div class="networks-bar">
    <div class="network-badge">✈️ Priority Pass — 1,400+ صالة</div>
    <div class="network-badge">🔑 LoungeKey — 1,000+ صالة</div>
    <div class="network-badge">💎 Diners Club — 900+ صالة</div>
    <div class="network-badge">🌐 DragonPass — 1,300+ صالة</div>
  </div>
</section>

<!-- PAYMENT -->
<div class="payment-section">
  <h3>🔐 طرق الدفع المقبولة</h3>
  <div class="payment-icons">
    <div class="payment-icon"><span class="visa-logo">VISA</span> فيزا</div>
    <div class="payment-icon">
      <div class="mc-logo">
        <div class="mc-circle mc-orange"></div>
        <div class="mc-circle mc-red"></div>
      </div>
      ماستر كارد
    </div>
    <div class="payment-icon">💵 دفع نقدي</div>
    <div class="payment-icon">📱 تحويل بنكي</div>
    <div class="payment-icon">₿ USDT</div>
  </div>
</div>

<!-- FEATURES -->
<h2 class="section-title" id="features">لماذا <span>نحن؟</span></h2>
<p class="section-sub">نقدم لك أفضل خدمة بأعلى معايير الأمان</p>
<div class="features">
  <div class="feature-box"><div class="feature-icon">⚡</div><h4>تسليم فوري</h4><p>استلم بطاقتك خلال ثوانٍ بعد الدفع</p></div>
  <div class="feature-box"><div class="feature-icon">🔒</div><h4>أمان 100%</h4><p>بياناتك محمية بأعلى تقنيات التشفير</p></div>
  <div class="feature-box"><div class="feature-icon">✈️</div><h4>صالات عالمية</h4><p>ادخل أكثر من 1,400 صالة مطار حول العالم</p></div>
  <div class="feature-box"><div class="feature-icon">🌍</div><h4>قبول عالمي</h4><p>تعمل في جميع أنحاء العالم</p></div>
  <div class="feature-box"><div class="feature-icon">🎧</div><h4>دعم 24/7</h4><p>فريق دعم متاح دائماً لمساعدتك</p></div>
</div>

<footer>
  <div class="footer-logos">
    <span class="visa-logo">VISA</span>
    <div class="mc-logo">
      <div class="mc-circle mc-orange" style="width:18px;height:18px;"></div>
      <div class="mc-circle mc-red" style="width:18px;height:18px;margin-right:-6px;"></div>
    </div>
    <span>✈️ Priority Pass</span>
    <span>🔒 SSL Secured</span>
  </div>
  <p>2025 DigitalCards — جميع الحقوق محفوظة</p>
  <p style="margin-top:6px;">سياسة الخصوصية | شروط الاستخدام | تواصل معنا</p>
</footer>

<!-- MODAL -->
<div class="modal-overlay" id="modalOverlay">
  <div class="modal">
    <button class="close-btn" onclick="closeModal()">X</button>
    <div id="orderForm">
      <h3>اتمام الطلب</h3>
      <p class="sub">أدخل بياناتك لإتمام عملية الشراء</p>
      <div class="price-display" id="modalPrice">$5.00</div>
      <label>المنتج</label>
      <input type="text" id="modalProduct" readonly />
      <label>الاسم الكامل</label>
      <input type="text" placeholder="أدخل اسمك الكامل" id="inputName" />
      <label>البريد الإلكتروني</label>
      <input type="email" placeholder="example@email.com" id="inputEmail" dir="ltr" />
      <label>طريقة الدفع</label>
      <select id="payMethod">
        <option value="">-- اختر طريقة الدفع --</option>
        <option>فيزا / ماستر كارد</option>
        <option>تحويل بنكي</option>
        <option>USDT</option>
        <option>دفع نقدي</option>
      </select>
      <button class="btn-confirm" onclick="confirmOrder()">تأكيد الطلب</button>
    </div>
    <div class="success-msg" id="successMsg">
      <div class="check">✅</div>
      <h3>تم استلام طلبك بنجاح!</h3>
      <p>سيتم التواصل معك عبر البريد الإلكتروني خلال دقائق.</p>
      <br/>
      <button class="btn-confirm" onclick="closeModal()">إغلاق</button>
    </div>
  </div>
</div>

<script>
  function openModal(product, price) {
    document.getElementById('modalProduct').value = product;
    document.getElementById('modalPrice').textContent = price;
    document.getElementById('orderForm').style.display = 'block';
    document.getElementById('successMsg').style.display = 'none';
    document.getElementById('inputName').value = '';
    document.getElementById('inputEmail').value = '';
    document.getElementById('payMethod').value = '';
    document.getElementById('modalOverlay').classList.add('active');
  }
  function closeModal() {
    document.getElementById('modalOverlay').classList.remove('active');
  }
  function confirmOrder() {
    var name = document.getElementById('inputName').value.trim();
    var email = document.getElementById('inputEmail').value.trim();
    var pay = document.getElementById('payMethod').value;
    if (!name || !email || !pay) { alert('يرجى ملء جميع الحقول'); return; }
    if (!email.includes('@')) { alert('يرجى إدخال بريد صحيح'); return; }
    document.getElementById('orderForm').style.display = 'none';
    document.getElementById('successMsg').style.display = 'block';
  }
  document.getElementById('modalOverlay').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
  });
</script>

</body>
</html>
"""

HTML(html_code)

